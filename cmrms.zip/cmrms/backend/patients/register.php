<?php
// backend/patients/register.php - UPDATED FOR JSON
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../config/database.php';

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Log the request
error_log("Registration attempt: " . print_r($input, true));

if ($input) {
    $database = new Database();
    $db = $database->getConnection();
    
    // Get form data from JSON
    $id_number = $input['id_number'] ?? '';
    $email = $input['email'] ?? '';
    $password = $input['password'] ?? '';
    $first_name = $input['first_name'] ?? '';
    $last_name = $input['last_name'] ?? '';
    $date_of_birth = $input['date_of_birth'] ?? '';
    $gender = $input['gender'] ?? '';
    $phone_number = $input['phone_number'] ?? '';
    $address = $input['address'] ?? '';
    $insurance_provider = $input['insurance_provider'] ?? '';
    
    error_log("Processing registration for: $first_name $last_name");
    
    // Validate required fields
    if (empty($id_number) || empty($email) || empty($password) || empty($first_name) || empty($last_name)) {
        error_log("Missing required fields");
        echo json_encode(['success' => false, 'message' => 'All fields are required']);
        exit;
    }
    
    try {
        $db->beginTransaction();
        
        // Check if user already exists
        $check_query = "SELECT user_id FROM users WHERE id_number = ? OR email = ?";
        $check_stmt = $db->prepare($check_query);
        $check_stmt->execute([$id_number, $email]);
        
        if ($check_stmt->rowCount() > 0) {
            error_log("User already exists: $id_number or $email");
            echo json_encode(['success' => false, 'message' => 'ID number or email already exists']);
            $db->rollBack();
            exit;
        }
        
        // Hash password
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert into users table
        $user_query = "INSERT INTO users (id_number, email, password_hash, user_type) 
                       VALUES (?, ?, ?, 'patient')";
        $user_stmt = $db->prepare($user_query);
        $user_stmt->execute([$id_number, $email, $password_hash]);
        $user_id = $db->lastInsertId();
        
        error_log("User created with ID: $user_id");
        
        // Insert into patients table
        $patient_query = "INSERT INTO patients (user_id, first_name, last_name, date_of_birth, 
                          gender, phone_number, address, insurance_provider) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $patient_stmt = $db->prepare($patient_query);
        $patient_stmt->execute([
            $user_id, 
            $first_name, 
            $last_name, 
            $date_of_birth, 
            $gender, 
            $phone_number, 
            $address, 
            $insurance_provider
        ]);
        
        $patient_id = $db->lastInsertId();
        error_log("Patient created with ID: $patient_id");
        
        $db->commit();
        
        error_log("Registration successful for: $first_name $last_name");
        echo json_encode(['success' => true, 'message' => 'Registration successful! You can now login.']);
        
    } catch (Exception $e) {
        $db->rollBack();
        error_log("Registration error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Registration failed: ' . $e->getMessage()]);
    }
} else {
    error_log("No JSON data received");
    echo json_encode(['success' => false, 'message' => 'No data received']);
}
?>