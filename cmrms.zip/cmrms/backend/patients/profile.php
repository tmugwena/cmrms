<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();

// Ensure patient is logged in
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'patient') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

$patient_id = $_SESSION['patient_id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch patient profile data
    $query = "SELECT p.patient_id, p.first_name, p.last_name, p.date_of_birth, p.gender,
                     p.phone_number, p.address, p.insurance_provider,
                     u.email, u.id_number
              FROM patients p
              JOIN users u ON p.user_id = u.user_id
              WHERE p.patient_id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$patient_id]);
    $patient = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($patient) {
        echo json_encode(['success' => true, 'data' => $patient]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Patient not found']);
    }

} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update patient and user info
    $first_name = $_POST['first_name'] ?? '';
    $last_name = $_POST['last_name'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone_number = $_POST['phone_number'] ?? '';
    $address = $_POST['address'] ?? '';
    $insurance_provider = $_POST['insurance_provider'] ?? '';

    // Get user_id from patient_id
    $getUserQuery = "SELECT user_id FROM patients WHERE patient_id = ?";
    $stmt = $db->prepare($getUserQuery);
    $stmt->execute([$patient_id]);
    $user_id = $stmt->fetchColumn();

    if (!$user_id) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }

    try {
        // Update users table
        $queryUser = "UPDATE users SET email = ? WHERE user_id = ?";
        $stmtUser = $db->prepare($queryUser);
        $stmtUser->execute([$email, $user_id]);

        // Update patients table
        $queryPatient = "UPDATE patients 
                         SET first_name = ?, last_name = ?, gender = ?, 
                             phone_number = ?, address = ?, insurance_provider = ?
                         WHERE patient_id = ?";
        $stmtPatient = $db->prepare($queryPatient);
        $stmtPatient->execute([$first_name, $last_name, $gender, $phone_number, $address, $insurance_provider, $patient_id]);

        echo json_encode(['success' => true, 'message' => 'Profile updated successfully']);
    } catch (Exception $e) {
        error_log("Profile update error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error updating profile']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
