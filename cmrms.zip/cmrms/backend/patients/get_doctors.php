<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

try {
    $database = new Database();
    $db = $database->getConnection();

    // Get doctors (or any staff with role 'Doctor')
    $query = "SELECT staff_id, first_name, last_name, role 
              FROM staff 
              WHERE role IN ('Doctor', 'Nurse Practitioner') 
              ORDER BY first_name ASC";

    $stmt = $db->prepare($query);
    $stmt->execute();

    $doctors = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($doctors) {
        echo json_encode(['success' => true, 'data' => $doctors]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No doctors found']);
    }
} catch (Exception $e) {
    error_log("Error fetching doctors: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Failed to load doctors']);
}
?>
