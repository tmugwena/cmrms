<?php
header('Content-Type: application/json');

// database connection
include('../db_connect.php');

if (!isset($_GET['doctor_id']) || !isset($_GET['date'])) {
    echo json_encode(['success' => false, 'message' => 'Doctor ID and date required']);
    exit;
}

$doctor_id = $_GET['doctor_id'];
$date = $_GET['date'];

try {
    // Fetch existing appointments for the doctor on that date
    $stmt = $conn->prepare("SELECT appointment_time FROM appointments WHERE staff_id = :doctor_id AND appointment_date = :date AND status = 'Scheduled'");
    $stmt->execute(['doctor_id' => $doctor_id, 'date' => $date]);
    $appointments = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // 15 min time intervals
    $start = new DateTime('09:00');
    $end = new DateTime('17:00');
    $interval = new DateInterval('PT15M');

    $slots = [];
    for ($time = clone $start; $time < $end; $time->add($interval)) {
        $slot = $time->format('H:i');
        if (!in_array($slot, $appointments)) {
            $slots[] = $slot;
        }
    }

    if (count($slots) === 0) {
        echo json_encode(['success' => false, 'message' => 'No available time slots for this date']);
        exit;
    }

    echo json_encode(['success' => true, 'data' => $slots]);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Error fetching available times: ' . $e->getMessage()]);
}
