<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'patient') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

$patient_id = $_SESSION['patient_id'];

try {
    // Get patient basic info
    $patient_query = "SELECT p.first_name, p.last_name 
                      FROM patients p 
                      WHERE p.patient_id = ?";
    $patient_stmt = $db->prepare($patient_query);
    $patient_stmt->execute([$patient_id]);
    $patient_info = $patient_stmt->fetch(PDO::FETCH_ASSOC);

    // Upcoming appointments count
    $today = date('Y-m-d');
    $upcoming_query = "SELECT COUNT(*) as upcoming_count 
                       FROM appointments 
                       WHERE patient_id = ? AND appointment_date >= ? AND status != 'Cancelled'";
    $upcoming_stmt = $db->prepare($upcoming_query);
    $upcoming_stmt->execute([$patient_id, $today]);
    $upcoming_count = $upcoming_stmt->fetch(PDO::FETCH_ASSOC);

    // Recent appointments (last 3)
    $recent_query = "SELECT a.*, s.first_name as staff_first_name, s.last_name as staff_last_name, s.role
                     FROM appointments a 
                     JOIN staff s ON a.staff_id = s.staff_id 
                     WHERE a.patient_id = ? 
                     ORDER BY a.appointment_date DESC, a.appointment_time DESC 
                     LIMIT 3";
    $recent_stmt = $db->prepare($recent_query);
    $recent_stmt->execute([$patient_id]);
    $recent_appointments = $recent_stmt->fetchAll(PDO::FETCH_ASSOC);

    $dashboard_data = [
        'first_name' => $patient_info['first_name'],
        'last_name' => $patient_info['last_name'],
        'patient_id' => $patient_id,
        'upcoming_appointments' => $upcoming_count['upcoming_count'],
        'recent_appointments' => $recent_appointments
    ];

    echo json_encode(['success' => true, 'data' => $dashboard_data]);

} catch (Exception $e) {
    error_log("Patient dashboard error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error loading dashboard: ' . $e->getMessage()]);
}
?>