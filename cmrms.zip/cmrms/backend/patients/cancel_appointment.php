<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'patient') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();
$patient_id = $_SESSION['patient_id'];

$input = json_decode(file_get_contents('php://input'), true);

if ($input && isset($input['appointment_id'])) {
    $appointment_id = $input['appointment_id'];
    
    try {
        // Verify the appointment belongs to the patient
        $verify_query = "SELECT appointment_id FROM appointments 
                        WHERE appointment_id = ? AND patient_id = ? AND status != 'Cancelled'";
        $verify_stmt = $db->prepare($verify_query);
        $verify_stmt->execute([$appointment_id, $patient_id]);
        
        if ($verify_stmt->rowCount() === 0) {
            echo json_encode(['success' => false, 'message' => 'Appointment not found or already cancelled']);
            exit;
        }

        // Cancel the appointment
        $cancel_query = "UPDATE appointments SET status = 'Cancelled' WHERE appointment_id = ?";
        $cancel_stmt = $db->prepare($cancel_query);
        $cancel_stmt->execute([$appointment_id]);

        echo json_encode(['success' => true, 'message' => 'Appointment cancelled successfully']);

    } catch (Exception $e) {
        error_log("Cancel appointment error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error cancelling appointment']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'No appointment ID provided']);
}
?>