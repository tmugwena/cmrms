<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

$input = json_decode(file_get_contents('php://input'), true);

if ($input) {
    $patient_id = $_SESSION['user_type'] === 'patient' ? $_SESSION['patient_id'] : $input['patient_id'];
    $staff_id = $input['staff_id'];
    $appointment_date = $input['appointment_date'];
    $appointment_time = $input['appointment_time'];
    $appointment_type = $input['appointment_type'];
    $reason = $input['reason'] ?? '';
    $created_by = $_SESSION['staff_id'] ?? $staff_id;

    // Validate date and time
    $appointmentDateTime = strtotime("$appointment_date $appointment_time");
    if ($appointmentDateTime < time()) {
        echo json_encode(['success' => false, 'message' => 'Cannot book an appointment in the past']);
        exit;
    }

    try {
        $conflict_query = "SELECT appointment_id FROM appointments 
                          WHERE staff_id = ? AND appointment_date = ? AND appointment_time = ? 
                          AND status != 'Cancelled'";
        $conflict_stmt = $db->prepare($conflict_query);
        $conflict_stmt->execute([$staff_id, $appointment_date, $appointment_time]);
        
        if ($conflict_stmt->rowCount() > 0) {
            echo json_encode(['success' => false, 'message' => 'Time slot already booked']);
            exit;
        }

        $query = "INSERT INTO appointments (patient_id, staff_id, appointment_date, 
                  appointment_time, appointment_type, reason, created_by, status) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, 'Scheduled')";
        $stmt = $db->prepare($query);
        $stmt->execute([$patient_id, $staff_id, $appointment_date, $appointment_time, 
                       $appointment_type, $reason, $created_by]);
        
        echo json_encode(['success' => true, 'message' => 'Appointment booked successfully']);
        
    } catch (Exception $e) {
        error_log("Booking error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Booking failed']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'No data received']);
}
