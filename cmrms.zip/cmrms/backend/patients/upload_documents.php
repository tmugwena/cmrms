<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'patient') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();
$patient_id = $_SESSION['patient_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!isset($_FILES['document']) || $_FILES['document']['error'] !== UPLOAD_ERR_OK) {
            echo json_encode(['success' => false, 'message' => 'No file uploaded or upload error']);
            exit;
        }

        $uploadedFile = $_FILES['document'];
        $allowedTypes = ['application/pdf', 'text/csv', 'application/vnd.ms-excel'];
        $maxFileSize = 10 * 1024 * 1024; // 10MB

        // Validate file type
        if (!in_array($uploadedFile['type'], $allowedTypes)) {
            echo json_encode(['success' => false, 'message' => 'Only PDF and CSV files are allowed']);
            exit;
        }

        // Validate file size
        if ($uploadedFile['size'] > $maxFileSize) {
            echo json_encode(['success' => false, 'message' => 'File size must be less than 10MB']);
            exit;
        }

        // Create uploads directory if it doesn't exist
        $uploadDir = '../../uploads/patients/' . $patient_id . '/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        // Generate unique filename
        $fileExtension = pathinfo($uploadedFile['name'], PATHINFO_EXTENSION);
        $fileName = uniqid() . '_' . preg_replace('/[^a-zA-Z0-9\.]/', '_', $uploadedFile['name']);
        $filePath = $uploadDir . $fileName;

        // Move uploaded file
        if (move_uploaded_file($uploadedFile['tmp_name'], $filePath)) {
            // Save to database
            $query = "INSERT INTO patient_documents (patient_id, document_name, file_path, file_type, file_size, description) 
                      VALUES (?, ?, ?, ?, ?, ?)";
            
            $stmt = $db->prepare($query);
            $stmt->execute([
                $patient_id,
                $uploadedFile['name'],
                $filePath,
                $uploadedFile['type'],
                $uploadedFile['size'],
                $_POST['description'] ?? ''
            ]);

            echo json_encode(['success' => true, 'message' => 'Document uploaded successfully']);
        } else {
            throw new Exception('Failed to move uploaded file');
        }

    } catch (Exception $e) {
        error_log("Document upload error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Upload failed: ' . $e->getMessage()]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get patient documents
    try {
        $query = "SELECT document_id, document_name, file_type, file_size, description, uploaded_at
                  FROM patient_documents 
                  WHERE patient_id = ? 
                  ORDER BY uploaded_at DESC";
        
        $stmt = $db->prepare($query);
        $stmt->execute([$patient_id]);
        $documents = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'data' => $documents]);

    } catch (Exception $e) {
        error_log("Get documents error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error loading documents']);
    }
}
?>