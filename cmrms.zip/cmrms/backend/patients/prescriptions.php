<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'patient') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

$patient_id = $_SESSION['patient_id'];

try {
    $query = "SELECT p.*, s.first_name as staff_first_name, s.last_name as staff_last_name, s.role
              FROM prescriptions p
              JOIN staff s ON p.staff_id = s.staff_id
              WHERE p.patient_id = ?
              ORDER BY p.created_at DESC";
    $stmt = $db->prepare($query);
    $stmt->execute([$patient_id]);
    $prescriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $prescriptions]);
    
} catch (Exception $e) {
    error_log("Patient prescriptions error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error loading prescriptions: ' . $e->getMessage()]);
}
?>