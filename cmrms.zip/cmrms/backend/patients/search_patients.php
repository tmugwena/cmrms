<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'patient') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

$patient_id = $_SESSION['patient_id'];

try {
    // For patients, they can only search their own profile
    $query = "SELECT p.patient_id, p.first_name, p.last_name, p.phone_number, 
                     p.insurance_provider, u.id_number, u.email,
                     p.date_of_birth, p.gender, p.address
              FROM patients p 
              JOIN users u ON p.user_id = u.user_id 
              WHERE p.patient_id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$patient_id]);
    $patient = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($patient) {
        echo json_encode(['success' => true, 'data' => [$patient]]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Patient not found']);
    }

} catch (Exception $e) {
    error_log("Patient search error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error searching patient: ' . $e->getMessage()]);
}
?>