<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'patient') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();
$patient_id = $_SESSION['patient_id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $query = "SELECT mr.*, s.first_name as staff_first_name, s.last_name as staff_last_name, s.role
                  FROM medical_records mr
                  JOIN staff s ON mr.staff_id = s.staff_id
                  WHERE mr.patient_id = ?
                  ORDER BY mr.record_date DESC, mr.created_at DESC";
        
        $stmt = $db->prepare($query);
        $stmt->execute([$patient_id]);
        $medical_records = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'data' => $medical_records]);

    } catch (Exception $e) {
        error_log("Medical history error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error loading medical history']);
    }
}
?>