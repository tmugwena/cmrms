<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

$date = $_GET['date'] ?? date('Y-m-d');
$staff_id = $_GET['staff_id'] ?? '';

try {
    // Define available time slots (9 AM to 5 PM, 30-minute intervals)
    $start_time = strtotime('09:00');
    $end_time = strtotime('17:00');
    $interval = 30 * 60; // 30 minutes in seconds
    
    $available_slots = [];
    $current_time = $start_time;
    
    while ($current_time <= $end_time) {
        $time_slot = date('H:i', $current_time);
        
        // Check if slot is already booked
        if ($staff_id) {
            $check_query = "SELECT appointment_id FROM appointments 
                           WHERE staff_id = ? AND appointment_date = ? AND appointment_time = ? 
                           AND status != 'Cancelled'";
            $check_stmt = $db->prepare($check_query);
            $check_stmt->execute([$staff_id, $date, $time_slot]);
            
            $is_available = $check_stmt->rowCount() === 0;
        } else {
            $is_available = true;
        }
        
        $available_slots[] = [
            'time' => $time_slot,
            'available' => $is_available
        ];
        
        $current_time += $interval;
    }

    echo json_encode(['success' => true, 'data' => $available_slots]);

} catch (Exception $e) {
    error_log("Timeslots error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error loading time slots']);
}
?>