<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'staff') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get all appointments
    $query = "SELECT a.*, p.first_name as patient_first_name, p.last_name as patient_last_name,
                     s.first_name as staff_first_name, s.last_name as staff_last_name
              FROM appointments a 
              JOIN patients p ON a.patient_id = p.patient_id 
              JOIN staff s ON a.staff_id = s.staff_id 
              ORDER BY a.appointment_date DESC, a.appointment_time DESC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $appointments]);
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update appointment status
    $appointment_id = $_POST['appointment_id'];
    $status = $_POST['status'];
    
    $query = "UPDATE appointments SET status = ? WHERE appointment_id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$status, $appointment_id]);
    
    echo json_encode(['success' => true, 'message' => 'Appointment updated successfully']);
}
?>