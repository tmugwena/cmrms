<?php
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['role'] !== 'admin') {
    header('HTTP/1.0 403 Forbidden');
    exit;
}

$database = new Database();
$db = $database->getConnection();

$report_type = $_GET['type'] ?? 'patients';
$format = $_GET['format'] ?? 'csv';

try {
    switch ($report_type) {
        case 'patients':
            $query = "SELECT p.patient_id, p.first_name, p.last_name, p.date_of_birth, 
                             p.gender, p.phone_number, p.insurance_provider, p.address,
                             u.id_number, u.email, u.created_at
                      FROM patients p 
                      JOIN users u ON p.user_id = u.user_id 
                      ORDER BY p.first_name, p.last_name";
            $filename = 'patients_report';
            break;
            
        case 'appointments':
            $query = "SELECT a.appointment_id, p.first_name as patient_first_name, p.last_name as patient_last_name,
                             s.first_name as staff_first_name, s.last_name as staff_last_name,
                             a.appointment_date, a.appointment_time, a.appointment_type, a.status, a.reason
                      FROM appointments a 
                      JOIN patients p ON a.patient_id = p.patient_id 
                      JOIN staff s ON a.staff_id = s.staff_id 
                      ORDER BY a.appointment_date DESC";
            $filename = 'appointments_report';
            break;
            
        case 'prescriptions':
            $query = "SELECT pr.prescription_id, p.first_name as patient_first_name, p.last_name as patient_last_name,
                             s.first_name as staff_first_name, s.last_name as staff_last_name,
                             pr.medication_name, pr.dosage, pr.frequency, pr.start_date, pr.end_date, pr.status
                      FROM prescriptions pr 
                      JOIN patients p ON pr.patient_id = p.patient_id 
                      JOIN staff s ON pr.staff_id = s.staff_id 
                      ORDER BY pr.created_at DESC";
            $filename = 'prescriptions_report';
            break;
    }
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($format === 'csv') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
        
        $output = fopen('php://output', 'w');
        
        // Add headers
        if (!empty($data)) {
            fputcsv($output, array_keys($data[0]));
        }
        
        // Add data
        foreach ($data as $row) {
            fputcsv($output, $row);
        }
        
        fclose($output);
        
    } elseif ($format === 'pdf') {
        // For PDF, you would need a PDF library like TCPDF or Dompdf
        // This is a simplified version - you'd need to implement proper PDF generation
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '.pdf"');
        
        // Simple PDF content - replace with proper PDF generation
        echo "%PDF-1.4\n";
        echo "1 0 obj\n";
        echo "<< /Type /Catalog /Pages 2 0 R >>\n";
        echo "endobj\n";
        echo "2 0 obj\n";
        echo "<< /Type /Pages /Kids [3 0 R] /Count 1 >>\n";
        echo "endobj\n";
        echo "3 0 obj\n";
        echo "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R >>\n";
        echo "endobj\n";
        echo "4 0 obj\n";
        echo "<< /Length 44 >>\n";
        echo "stream\n";
        echo "BT /F1 12 Tf 100 700 Td (" . $report_type . " Report) Tj ET\n";
        echo "endstream\n";
        echo "endobj\n";
        echo "xref\n";
        echo "0 5\n";
        echo "0000000000 65535 f \n";
        echo "0000000009 00000 n \n";
        echo "0000000058 00000 n \n";
        echo "0000000115 00000 n \n";
        echo "0000000232 00000 n \n";
        echo "trailer\n";
        echo "<< /Size 5 /Root 1 0 R >>\n";
        echo "startxref\n";
        echo "309\n";
        echo "%%EOF";
    }
    
} catch (Exception $e) {
    error_log("Export report error: " . $e->getMessage());
    header('HTTP/1.0 500 Internal Server Error');
    echo 'Error generating report: ' . $e->getMessage();
}
?>