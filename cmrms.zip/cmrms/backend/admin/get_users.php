<?php
header('Content-Type: application/json');
session_start();
require_once '../../config/database.php';

// Only admins can view users
if(!isset($_SESSION['role']) || strtolower($_SESSION['role'])!=='admin'){
    echo json_encode([]);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();

    $stmt = $db->prepare("
        SELECT u.user_id, 
               COALESCE(s.first_name, p.first_name) AS first_name,
               COALESCE(s.last_name, p.last_name) AS last_name,
               u.user_type,
               u.is_active,
               s.role
        FROM users u
        LEFT JOIN staff s ON u.user_id = s.user_id
        LEFT JOIN patients p ON u.user_id = p.user_id
        ORDER BY u.user_id ASC
    ");
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($users);

} catch (Exception $e) {
    error_log("Error fetching users: ".$e->getMessage());
    echo json_encode([]);
}
?>
