<?php
header('Content-Type: application/json');
session_start();
require_once '../../config/database.php';

// Only admins can view audit logs
if(!isset($_SESSION['role']) || strtolower($_SESSION['role'])!=='admin'){
    echo json_encode([]);
    exit();
}

try {
    $db = (new Database())->getConnection();

    $stmt = $db->prepare("
        SELECT a.log_id,
               a.admin_user_id,
               u.id_number AS admin_id_number,
               s.first_name AS admin_first,
               s.last_name AS admin_last,
               a.action,
               a.target_user_id,
               a.created_at
        FROM admin_audit_logs a
        JOIN users u ON a.admin_user_id = u.user_id
        LEFT JOIN staff s ON u.user_id = s.user_id
        ORDER BY a.created_at DESC
    ");
    $stmt->execute();
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($logs);

} catch (Exception $e) {
    error_log("Error fetching audit logs: ".$e->getMessage());
    echo json_encode([]);
}
?>
