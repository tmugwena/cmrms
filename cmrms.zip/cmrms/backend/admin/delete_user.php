<?php
header('Content-Type: application/json');
session_start();
require_once '../../config/database.php';

if(!isset($_SESSION['role']) || strtolower($_SESSION['role'])!=='admin'){
    echo json_encode(['success'=>false,'message'=>'Unauthorized']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$user_id = $input['user_id'] ?? 0;

if(!$user_id){
    echo json_encode(['success'=>false,'message'=>'User ID required']);
    exit();
}

try{
    $db = (new Database())->getConnection();

    // Delete user
    $stmt = $db->prepare("DELETE FROM users WHERE user_id=:user_id");
    $stmt->execute([':user_id'=>$user_id]);

    // Log action
    $stmtLog = $db->prepare("
        INSERT INTO admin_audit_logs (admin_user_id, action, target_user_id)
        VALUES (:admin_id, :action, :target_id)
    ");
    $stmtLog->execute([
        ':admin_id'=>$_SESSION['user_id'],
        ':action'=>"Deleted user ID: $user_id",
        ':target_id'=>$user_id
    ]);

    echo json_encode(['success'=>true,'message'=>'User deleted successfully']);

}catch(Exception $e){
    echo json_encode(['success'=>false,'message'=>'Error: '.$e->getMessage()]);
}
?>
