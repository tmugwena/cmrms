<?php
header('Content-Type: application/json');
session_start();
require_once '../../config/database.php';

// Only admins can view logs
if(!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin'){
    echo json_encode([]);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();

    $stmt = $db->prepare("
        SELECT l.log_id, l.admin_id, a.first_name AS admin_first_name, a.last_name AS admin_last_name,
               l.target_user_id, u.first_name AS target_first_name, u.last_name AS target_last_name,
               l.action, l.timestamp
        FROM audit_logs l
        LEFT JOIN staff a ON l.admin_id = a.user_id
        LEFT JOIN staff u ON l.target_user_id = u.user_id
        ORDER BY l.timestamp DESC
        LIMIT 50
    ");
    $stmt->execute();
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($logs);

} catch (Exception $e) {
    echo json_encode([]);
}
?>
