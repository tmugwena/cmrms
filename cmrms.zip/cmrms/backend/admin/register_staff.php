<?php
header('Content-Type: application/json');
session_start();
require_once '../../config/database.php';

// Only admins can register staff
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

$requiredFields = ['first_name', 'last_name', 'id_number', 'email', 'telephone', 'password', 'role'];

foreach ($requiredFields as $field) {
    if (empty($input[$field])) {
        echo json_encode(['success' => false, 'message' => "Field '$field' is required."]);
        exit();
    }
}

$first_name = trim($input['first_name']);
$last_name = trim($input['last_name']);
$id_number = trim($input['id_number']);
$email = trim($input['email']);
$telephone = trim($input['telephone']);
$password = $input['password'];
$role = trim($input['role']);
$specialization = isset($input['specialization']) ? trim($input['specialization']) : null;

try {
    $database = new Database();
    $db = $database->getConnection();

    // Start transaction
    $db->beginTransaction();

    // Insert into users table
    $stmt = $db->prepare("INSERT INTO users (id_number, email, password_hash, user_type) VALUES (?, ?, ?, 'staff')");
    $password_hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt->execute([$id_number, $email, $password_hash]);
    $user_id = $db->lastInsertId();

    // Insert into staff table
    $stmt = $db->prepare("INSERT INTO staff (user_id, first_name, last_name, role, phone_number, specialization, email) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $first_name, $last_name, $role, $telephone, $specialization, $email]);

    // Insert into admin_audit_logs
    $stmt = $db->prepare("INSERT INTO admin_audit_logs (admin_user_id, action, target_user_id) VALUES (?, ?, ?)");
    $admin_user_id = $_SESSION['user_id']; // logged-in admin
    $stmt->execute([$admin_user_id, 'Registered new staff', $user_id]);

    $db->commit();

    echo json_encode(['success' => true, 'message' => 'Staff registered successfully']);

} catch (Exception $e) {
    if ($db->inTransaction()) $db->rollBack();
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
