<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // Get all staff
        $query = "SELECT s.staff_id, s.first_name, s.last_name, s.role, 
                         u.email, u.id_number, u.is_active 
                  FROM staff s 
                  JOIN users u ON s.user_id = u.user_id 
                  ORDER BY s.role, s.first_name";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $staff = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'data' => $staff]);
        
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            echo json_encode(['success' => false, 'message' => 'No data received']);
            exit;
        }
        
        $staff_id = $input['staff_id'] ?? '';
        $action = $input['action'] ?? '';
        
        if ($action === 'update_role') {
            $new_role = $input['role'] ?? '';
            $valid_roles = ['admin', 'doctor', 'nurse', 'receptionist'];
            
            if (!in_array($new_role, $valid_roles)) {
                echo json_encode(['success' => false, 'message' => 'Invalid role']);
                exit;
            }
            
            $query = "UPDATE staff SET role = ? WHERE staff_id = ?";
            $stmt = $db->prepare($query);
            $stmt->execute([$new_role, $staff_id]);
            
            echo json_encode(['success' => true, 'message' => 'Staff role updated successfully']);
            
        } elseif ($action === 'toggle_status') {
            // Get current status
            $status_query = "SELECT u.is_active FROM users u 
                            JOIN staff s ON u.user_id = s.user_id 
                            WHERE s.staff_id = ?";
            $status_stmt = $db->prepare($status_query);
            $status_stmt->execute([$staff_id]);
            $current_status = $status_stmt->fetch(PDO::FETCH_ASSOC);
            
            $new_status = $current_status['is_active'] ? 0 : 1;
            
            $update_query = "UPDATE users u 
                            JOIN staff s ON u.user_id = s.user_id 
                            SET u.is_active = ? 
                            WHERE s.staff_id = ?";
            $update_stmt = $db->prepare($update_query);
            $update_stmt->execute([$new_status, $staff_id]);
            
            $status_text = $new_status ? 'activated' : 'deactivated';
            echo json_encode(['success' => true, 'message' => "Staff account $status_text"]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
        }
    }
} catch (Exception $e) {
    error_log("Manage staff error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>