<?php
header('Content-Type: application/json');
session_start();
require_once '../../config/database.php';

if(!isset($_SESSION['role']) || strtolower($_SESSION['role'])!=='admin'){
    echo json_encode(['success'=>false,'message'=>'Unauthorized']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$user_id = $input['user_id'] ?? null;
$new_password = $input['new_password'] ?? '';

if(!$user_id || !$new_password || strlen($new_password) < 6){
    echo json_encode(['success'=>false,'message'=>'Invalid input']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();

    $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

    $stmt = $db->prepare("UPDATE users SET password_hash=? WHERE user_id=?");
    $stmt->execute([$password_hash, $user_id]);

    if($stmt->rowCount() > 0){
        // Audit log
        $stmtLog = $db->prepare("INSERT INTO admin_audit_logs (admin_user_id, action, target_user_id) VALUES (?,?,?)");
        $stmtLog->execute([$_SESSION['user_id'], "Reset password", $user_id]);

        echo json_encode(['success'=>true,'message'=>'Password reset successfully']);
    } else {
        echo json_encode(['success'=>false,'message'=>'User not found or password unchanged']);
    }

} catch(Exception $e){
    error_log("Error resetting password: ".$e->
