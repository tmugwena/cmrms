<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'staff') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get prescriptions
    $patient_id = $_GET['patient_id'] ?? '';
    
    if ($patient_id) {
        $query = "SELECT p.*, pat.first_name as patient_first_name, pat.last_name as patient_last_name,
                         s.first_name as staff_first_name, s.last_name as staff_last_name
                  FROM prescriptions p
                  JOIN patients pat ON p.patient_id = pat.patient_id
                  JOIN staff s ON p.staff_id = s.staff_id
                  WHERE p.patient_id = ?
                  ORDER BY p.created_at DESC";
        $stmt = $db->prepare($query);
        $stmt->execute([$patient_id]);
    } else {
        $query = "SELECT p.*, pat.first_name as patient_first_name, pat.last_name as patient_last_name,
                         s.first_name as staff_first_name, s.last_name as staff_last_name
                  FROM prescriptions p
                  JOIN patients pat ON p.patient_id = pat.patient_id
                  JOIN staff s ON p.staff_id = s.staff_id
                  ORDER BY p.created_at DESC
                  LIMIT 50";
        $stmt = $db->prepare($query);
        $stmt->execute();
    }
    
    $prescriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'data' => $prescriptions]);
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'message' => 'No data received']);
        exit;
    }
    
    try {
        $query = "INSERT INTO prescriptions (patient_id, staff_id, medication_name, dosage, frequency, 
                  start_date, end_date, instructions, status) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $db->prepare($query);
        $stmt->execute([
            $input['patient_id'],
            $_SESSION['staff_id'],
            $input['medication_name'],
            $input['dosage'],
            $input['frequency'],
            $input['start_date'],
            $input['end_date'] ?? null,
            $input['instructions'] ?? '',
            $input['status'] ?? 'active'
        ]);
        
        echo json_encode(['success' => true, 'message' => 'Prescription created successfully']);
        
    } catch (Exception $e) {
        error_log("Prescription error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error creating prescription: ' . $e->getMessage()]);
    }
}
?>