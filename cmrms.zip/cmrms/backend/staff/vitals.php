<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'staff') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $patient_id = $_GET['patient_id'] ?? '';
    
    if ($patient_id) {
        $query = "SELECT v.*, pat.first_name as patient_first_name, pat.last_name as patient_last_name,
                         s.first_name as staff_first_name, s.last_name as staff_last_name
                  FROM patient_vitals v
                  JOIN patients pat ON v.patient_id = pat.patient_id
                  JOIN staff s ON v.staff_id = s.staff_id
                  WHERE v.patient_id = ?
                  ORDER BY v.recorded_at DESC";
        $stmt = $db->prepare($query);
        $stmt->execute([$patient_id]);
    } else {
        $query = "SELECT v.*, pat.first_name as patient_first_name, pat.last_name as patient_last_name,
                         s.first_name as staff_first_name, s.last_name as staff_last_name
                  FROM patient_vitals v
                  JOIN patients pat ON v.patient_id = pat.patient_id
                  JOIN staff s ON v.staff_id = s.staff_id
                  ORDER BY v.recorded_at DESC
                  LIMIT 50";
        $stmt = $db->prepare($query);
        $stmt->execute();
    }
    
    $vitals = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'data' => $vitals]);
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'message' => 'No data received']);
        exit;
    }
    
    try {
        $query = "INSERT INTO patient_vitals (patient_id, staff_id, blood_pressure, heart_rate, 
                  temperature, respiratory_rate, oxygen_saturation, weight, height, notes) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $db->prepare($query);
        $stmt->execute([
            $input['patient_id'],
            $_SESSION['staff_id'],
            $input['blood_pressure'] ?? null,
            $input['heart_rate'] ?? null,
            $input['temperature'] ?? null,
            $input['respiratory_rate'] ?? null,
            $input['oxygen_saturation'] ?? null,
            $input['weight'] ?? null,
            $input['height'] ?? null,
            $input['notes'] ?? ''
        ]);
        
        echo json_encode(['success' => true, 'message' => 'Vitals recorded successfully']);
        
    } catch (Exception $e) {
        error_log("Vitals error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error recording vitals: ' . $e->getMessage()]);
    }
}
?>