<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'staff') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

$category = $_GET['category'] ?? '';
$filter_value = $_GET['filter_value'] ?? '';

try {
    $query = "SELECT p.patient_id, p.first_name, p.last_name, p.phone_number, 
                     p.insurance_provider, u.id_number, u.email,
                     p.date_of_birth, p.gender, p.address
              FROM patients p 
              JOIN users u ON p.user_id = u.user_id 
              WHERE u.is_active = 1";
    
    $params = [];
    
    // Apply filters based on category
    switch ($category) {
        case 'insurance':
            $query .= " AND p.insurance_provider LIKE ?";
            $params[] = "%$filter_value%";
            break;
        case 'age':
            // Calculate age based on date_of_birth
            if ($filter_value === 'child') {
                $query .= " AND TIMESTAMPDIFF(YEAR, p.date_of_birth, CURDATE()) < 18";
            } elseif ($filter_value === 'adult') {
                $query .= " AND TIMESTAMPDIFF(YEAR, p.date_of_birth, CURDATE()) BETWEEN 18 AND 65";
            } elseif ($filter_value === 'senior') {
                $query .= " AND TIMESTAMPDIFF(YEAR, p.date_of_birth, CURDATE()) > 65";
            }
            break;
        case 'gender':
            $query .= " AND p.gender = ?";
            $params[] = $filter_value;
            break;
        case 'cross_border':
            // Assuming cross-border patients have specific insurance or address
            $query .= " AND (p.insurance_provider LIKE '%foreign%' OR p.address LIKE '%border%')";
            break;
    }
    
    $query .= " ORDER BY p.first_name, p.last_name";
    
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $patients, 'count' => count($patients)]);

} catch (Exception $e) {
    error_log("Patient categories error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error filtering patients: ' . $e->getMessage()]);
}
?>