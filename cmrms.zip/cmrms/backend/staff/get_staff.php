<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type'])) {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    $query = "SELECT s.staff_id, s.first_name, s.last_name, s.role, s.specialization, u.is_active
              FROM staff s 
              JOIN users u ON s.user_id = u.user_id 
              WHERE u.is_active = 1 
              ORDER BY s.role, s.first_name, s.last_name";
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    $staff = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $staff]);

} catch (Exception $e) {
    error_log("Get staff error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error loading staff: ' . $e->getMessage()]);
}
?>