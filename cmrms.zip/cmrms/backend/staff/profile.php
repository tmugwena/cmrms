<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'staff') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();
$staff_id = $_SESSION['staff_id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $query = "SELECT s.staff_id, s.first_name, s.last_name, s.role, s.specialization, 
                         s.phone_number, u.email, u.id_number, u.created_at
                  FROM staff s 
                  JOIN users u ON s.user_id = u.user_id 
                  WHERE s.staff_id = ?";
        
        $stmt = $db->prepare($query);
        $stmt->execute([$staff_id]);
        $staff_profile = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'data' => $staff_profile]);

    } catch (Exception $e) {
        error_log("Staff profile error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error loading profile']);
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'message' => 'No data received']);
        exit;
    }
    
    try {
        $phone_number = $input['phone_number'] ?? '';
        $specialization = $input['specialization'] ?? '';
        
        $query = "UPDATE staff SET phone_number = ?, specialization = ? WHERE staff_id = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$phone_number, $specialization, $staff_id]);

        echo json_encode(['success' => true, 'message' => 'Profile updated successfully']);

    } catch (Exception $e) {
        error_log("Update staff profile error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error updating profile']);
    }
}
?>