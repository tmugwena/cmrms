<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'staff') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $patient_id = $_GET['patient_id'] ?? '';
    
    if (empty($patient_id)) {
        echo json_encode(['success' => false, 'message' => 'Patient ID required']);
        exit;
    }
    
    try {
        // Get comprehensive patient details
        $query = "SELECT p.*, u.email, u.id_number, u.created_at, u.is_active
                  FROM patients p 
                  JOIN users u ON p.user_id = u.user_id 
                  WHERE p.patient_id = ?";
        
        $stmt = $db->prepare($query);
        $stmt->execute([$patient_id]);
        $patient = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$patient) {
            echo json_encode(['success' => false, 'message' => 'Patient not found']);
            exit;
        }
        
        // Get patient's recent appointments
        $appointments_query = "SELECT a.*, s.first_name as staff_first_name, s.last_name as staff_last_name
                              FROM appointments a 
                              JOIN staff s ON a.staff_id = s.staff_id 
                              WHERE a.patient_id = ? 
                              ORDER BY a.appointment_date DESC 
                              LIMIT 5";
        $appointments_stmt = $db->prepare($appointments_query);
        $appointments_stmt->execute([$patient_id]);
        $appointments = $appointments_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get patient's prescriptions
        $prescriptions_query = "SELECT p.*, s.first_name as staff_first_name, s.last_name as staff_last_name
                               FROM prescriptions p 
                               JOIN staff s ON p.staff_id = s.staff_id 
                               WHERE p.patient_id = ? 
                               ORDER BY p.created_at DESC 
                               LIMIT 5";
        $prescriptions_stmt = $db->prepare($prescriptions_query);
        $prescriptions_stmt->execute([$patient_id]);
        $prescriptions = $prescriptions_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get patient's medical records
        $records_query = "SELECT m.*, s.first_name as staff_first_name, s.last_name as staff_last_name
                         FROM medical_records m 
                         JOIN staff s ON m.staff_id = s.staff_id 
                         WHERE m.patient_id = ? 
                         ORDER BY m.record_date DESC 
                         LIMIT 5";
        $records_stmt = $db->prepare($records_query);
        $records_stmt->execute([$patient_id]);
        $medical_records = $records_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $patient_data = [
            'patient' => $patient,
            'appointments' => $appointments,
            'prescriptions' => $prescriptions,
            'medical_records' => $medical_records
        ];
        
        echo json_encode(['success' => true, 'data' => $patient_data]);
        
    } catch (Exception $e) {
        error_log("Patient details error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error loading patient details']);
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'message' => 'No data received']);
        exit;
    }
    
    $patient_id = $input['patient_id'] ?? '';
    $action = $input['action'] ?? '';
    
    if (empty($patient_id)) {
        echo json_encode(['success' => false, 'message' => 'Patient ID required']);
        exit;
    }
    
    try {
        if ($action === 'update') {
            // Update patient information
            $update_fields = [
                'first_name' => $input['first_name'],
                'last_name' => $input['last_name'],
                'date_of_birth' => $input['date_of_birth'],
                'gender' => $input['gender'],
                'phone_number' => $input['phone_number'],
                'address' => $input['address'],
                'insurance_provider' => $input['insurance_provider']
            ];
            
            $set_parts = [];
            $params = [];
            
            foreach ($update_fields as $field => $value) {
                $set_parts[] = "$field = ?";
                $params[] = $value;
            }
            
            $params[] = $patient_id;
            
            $query = "UPDATE patients SET " . implode(', ', $set_parts) . " WHERE patient_id = ?";
            $stmt = $db->prepare($query);
            $stmt->execute($params);
            
            echo json_encode(['success' => true, 'message' => 'Patient information updated successfully']);
            
        } elseif ($action === 'toggle_status') {
            // Toggle patient active status
            $status_query = "SELECT u.is_active FROM users u 
                            JOIN patients p ON u.user_id = p.user_id 
                            WHERE p.patient_id = ?";
            $status_stmt = $db->prepare($status_query);
            $status_stmt->execute([$patient_id]);
            $current_status = $status_stmt->fetch(PDO::FETCH_ASSOC);
            
            $new_status = $current_status['is_active'] ? 0 : 1;
            
            $update_query = "UPDATE users u 
                            JOIN patients p ON u.user_id = p.user_id 
                            SET u.is_active = ? 
                            WHERE p.patient_id = ?";
            $update_stmt = $db->prepare($update_query);
            $update_stmt->execute([$new_status, $patient_id]);
            
            $status_text = $new_status ? 'activated' : 'deactivated';
            echo json_encode(['success' => true, 'message' => "Patient account $status_text"]);
            
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
        }
        
    } catch (Exception $e) {
        error_log("Update patient error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error updating patient: ' . $e->getMessage()]);
    }
}
?>