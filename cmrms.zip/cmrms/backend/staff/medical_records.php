<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'staff') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $patient_id = $_GET['patient_id'] ?? '';
    
    if ($patient_id) {
        $query = "SELECT m.*, pat.first_name as patient_first_name, pat.last_name as patient_last_name,
                         s.first_name as staff_first_name, s.last_name as staff_last_name
                  FROM medical_records m
                  JOIN patients pat ON m.patient_id = pat.patient_id
                  JOIN staff s ON m.staff_id = s.staff_id
                  WHERE m.patient_id = ?
                  ORDER BY m.record_date DESC";
        $stmt = $db->prepare($query);
        $stmt->execute([$patient_id]);
    } else {
        $query = "SELECT m.*, pat.first_name as patient_first_name, pat.last_name as patient_last_name,
                         s.first_name as staff_first_name, s.last_name as staff_last_name
                  FROM medical_records m
                  JOIN patients pat ON m.patient_id = pat.patient_id
                  JOIN staff s ON m.staff_id = s.staff_id
                  ORDER BY m.record_date DESC
                  LIMIT 50";
        $stmt = $db->prepare($query);
        $stmt->execute();
    }
    
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'data' => $records]);
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'message' => 'No data received']);
        exit;
    }
    
    try {
        $query = "INSERT INTO medical_records (patient_id, staff_id, record_type, title, description, 
                  findings, treatment, record_date) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $db->prepare($query);
        $stmt->execute([
            $input['patient_id'],
            $_SESSION['staff_id'],
            $input['record_type'],
            $input['title'],
            $input['description'] ?? '',
            $input['findings'] ?? '',
            $input['treatment'] ?? '',
            $input['record_date']
        ]);
        
        echo json_encode(['success' => true, 'message' => 'Medical record created successfully']);
        
    } catch (Exception $e) {
        error_log("Medical record error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error creating medical record: ' . $e->getMessage()]);
    }
}
?>