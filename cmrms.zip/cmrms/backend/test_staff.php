<?php
header('Content-Type: application/json');
require_once '../config/database.php';

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "SELECT s.staff_id, s.first_name, s.last_name, s.role, u.is_active 
              FROM staff s 
              JOIN users u ON s.user_id = u.user_id 
              WHERE u.is_active = 1 
              ORDER BY s.role, s.first_name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $staff = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'data' => $staff, 'count' => count($staff)]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>