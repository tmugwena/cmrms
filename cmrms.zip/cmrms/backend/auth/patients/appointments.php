<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'patient') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

$patient_id = $_SESSION['patient_id'];

// Get patient appointments
$query = "SELECT a.*, s.first_name as staff_first_name, s.last_name as staff_last_name, s.role
          FROM appointments a 
          JOIN staff s ON a.staff_id = s.staff_id 
          WHERE a.patient_id = ? 
          ORDER BY a.appointment_date DESC, a.appointment_time DESC";
$stmt = $db->prepare($query);
$stmt->execute([$patient_id]);
$appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['success' => true, 'data' => $appointments]);
?>