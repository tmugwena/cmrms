<?php
header('Content-Type: application/json');
session_start();
require_once '../../config/database.php';

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if ($input) {
    $database = new Database();
    $db = $database->getConnection();
    
    $id_number = $input['id_number'] ?? '';
    $password = $input['password'] ?? '';
    $user_type = $input['user_type'] ?? '';
    
    error_log("Login attempt: $id_number, type: $user_type");
    
    try {
        if ($user_type === 'patient') {
            $query = "SELECT u.user_id, u.id_number, u.email, u.password_hash, u.user_type, 
                             p.patient_id, p.first_name, p.last_name 
                      FROM users u 
                      JOIN patients p ON u.user_id = p.user_id 
                      WHERE (u.id_number = ? OR u.email = ?) AND u.user_type = 'patient' AND u.is_active = 1";
        } else {
            $query = "SELECT u.user_id, u.id_number, u.email, u.password_hash, u.user_type,
                             s.staff_id, s.first_name, s.last_name, s.role 
                      FROM users u 
                      JOIN staff s ON u.user_id = s.user_id 
                      WHERE (u.id_number = ? OR u.email = ?) AND u.user_type = 'staff' AND u.is_active = 1";
        }
        
        $stmt = $db->prepare($query);
        $stmt->execute([$id_number, $id_number]);
        
        if ($stmt->rowCount() == 1) {
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Verify password
            if (password_verify($password, $user['password_hash'])) {
                // Regenerate session ID for security
                session_regenerate_id(true);
                
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['id_number'] = $user['id_number'];
                $_SESSION['user_type'] = $user['user_type'];
                $_SESSION['first_name'] = $user['first_name'];
                $_SESSION['last_name'] = $user['last_name'];
                $_SESSION['login_time'] = time();
                
                if ($user_type === 'patient') {
                    $_SESSION['patient_id'] = $user['patient_id'];
                    echo json_encode([
                        'success' => true, 
                        'message' => 'Login successful!',
                        'redirect' => 'patient_dashboard.html'
                    ]);
                } else {
                    $_SESSION['staff_id'] = $user['staff_id'];
                    $_SESSION['role'] = $user['role'];

                    // Check if admin
                    if (strtolower($user['role']) === 'admin') {
                        $redirectPage = 'admin_dashboard.html';
                    } else {
                        $redirectPage = 'staff_dashboard.html';
                    }

                    echo json_encode([
                        'success' => true, 
                        'message' => 'Login successful!',
                        'redirect' => $redirectPage
                    ]);
                }
                
                error_log("Login successful for: {$user['first_name']} {$user['last_name']} ({$user['user_type']})");
                
            } else {
                error_log("Invalid password for: $id_number");
                echo json_encode(['success' => false, 'message' => 'Invalid password']);
            }
        } else {
            error_log("User not found: $id_number, type: $user_type");
            echo json_encode(['success' => false, 'message' => 'User not found or account inactive']);
        }
    } catch (Exception $e) {
        error_log("Login error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    error_log("No data received in login request");
    echo json_encode(['success' => false, 'message' => 'No data received']);
}
?>