-- ------------------------------
-- Database: cmrms
-- ------------------------------

CREATE DATABASE IF NOT EXISTS cmrms CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE cmrms;

-- ------------------------------
-- Table: users
-- ------------------------------

CREATE TABLE `users` (
  `user_id` INT(11) NOT NULL AUTO_INCREMENT,
  `id_number` VARCHAR(20) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `user_type` ENUM('patient','staff','admin') NOT NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `id_number` (`id_number`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------
-- Table: staff
-- ------------------------------

CREATE TABLE `staff` (
  `staff_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL UNIQUE,
  `first_name` VARCHAR(100) NOT NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `role` ENUM('admin','doctor','nurse','receptionist') NOT NULL,
  `specialization` VARCHAR(100) DEFAULT NULL,
  `phone_number` VARCHAR(20) DEFAULT NULL,
  `email` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`staff_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------
-- Table: patients
-- ------------------------------

CREATE TABLE `patients` (
  `patient_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL UNIQUE,
  `first_name` VARCHAR(100) NOT NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `date_of_birth` DATE NOT NULL,
  `gender` ENUM('Male','Female','Other') NOT NULL,
  `phone_number` VARCHAR(20) DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `insurance_provider` VARCHAR(100) DEFAULT NULL,
  PRIMARY KEY (`patient_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------
-- Table: appointments
-- ------------------------------
CREATE TABLE appointments (
  appointment_id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  appointment_date DATE NOT NULL,
  appointment_time TIME NOT NULL,
  appointment_type ENUM('Consultation','Check-up','Follow-up','Emergency') NOT NULL,
  status ENUM('Scheduled','Confirmed','Completed','Cancelled') DEFAULT 'Scheduled',
  reason TEXT,
  FOREIGN KEY (patient_id) REFERENCES patients(patient_id)
);
 ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
-- ------------
-- table admin_audit_logs
-- -------------

CREATE TABLE IF NOT EXISTS admin_audit_logs (
  log_id INT AUTO_INCREMENT PRIMARY KEY,
  admin_user_id INT NOT NULL,
  action VARCHAR(255) NOT NULL,
  target_user_id INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (admin_user_id) REFERENCES users(user_id)
);

-- ------------------------------
-- Sample Data (Optional)
-- ------------------------------

-- Admin user
INSERT INTO `users` (id_number, email, password_hash, user_type)
VALUES ('ADMIN001', 'admin@cmrms.co.za', 'hashed_password_here', 'admin');

INSERT INTO `staff` (user_id, first_name, last_name, role, email)
VALUES (LAST_INSERT_ID(), 'System', 'Admin', 'admin', 'admin@cmrms.co.za');

-- Example patient
INSERT INTO `users` (id_number, email, password_hash, user_type)
VALUES ('8501155123089', 'sipho.mthembu@gmail.com', 'hashed_password_here', 'patient');

INSERT INTO `patients` (user_id, first_name, last_name, date_of_birth, gender, phone_number, address, insurance_provider)
VALUES (LAST_INSERT_ID(), 'Sipho', 'Mthembu', '1985-01-15', 'Male', '+27 11 456 7890', '123 Vilakazi Street, Soweto', 'Discovery Health');

-- Example staff
INSERT INTO `users` (id_number, email, password_hash, user_type)
VALUES ('8706205123087', 'dr.ntuli@cmrms.co.za', 'hashed_password_here', 'staff');

INSERT INTO `staff` (user_id, first_name, last_name, role, specialization, email)
VALUES (LAST_INSERT_ID(), 'Nomsa', 'Ntuli', 'doctor', 'Cardiology', 'dr.ntuli@cmrms.co.za');
