<?php
header('Content-Type: text/html; charset=utf-8');
require_once 'config/database.php';

echo "<h1>Database Structure Check</h1>";

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $tables = ['prescriptions', 'medical_records', 'patient_vitals'];
    
    foreach ($tables as $table) {
        $stmt = $db->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() > 0) {
            echo "<p style='color: green;'>✅ Table '$table' exists</p>";
        } else {
            echo "<p style='color: red;'>❌ Table '$table' does NOT exist</p>";
        }
    }
    
    // Check appointments table for created_by column
    $stmt = $db->query("SHOW COLUMNS FROM appointments LIKE 'created_by'");
    if ($stmt->rowCount() > 0) {
        echo "<p style='color: green;'>✅ 'created_by' column exists in appointments table</p>";
    } else {
        echo "<p style='color: red;'>❌ 'created_by' column missing from appointments table</p>";
    }
    
} catch(PDOException $e) {
    echo "<p style='color: red;'>❌ Connection failed: " . $e->getMessage() . "</p>";
}
?>