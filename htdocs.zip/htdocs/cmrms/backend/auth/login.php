<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

if ($_POST) {
    $database = new Database();
    $db = $database->getConnection();
    
    $id_number = $_POST['id_number'];
    $password = $_POST['password'];
    $user_type = $_POST['user_type'];
    
    try {
        if ($user_type === 'patient') {
            $query = "SELECT u.user_id, u.id_number, u.email, u.user_type, 
                             p.patient_id, p.first_name, p.last_name 
                      FROM users u 
                      JOIN patients p ON u.user_id = p.user_id 
                      WHERE u.id_number = ? AND u.user_type = 'patient'";
        } else {
            $query = "SELECT u.user_id, u.id_number, u.email, u.user_type,
                             s.staff_id, s.first_name, s.last_name, s.role 
                      FROM users u 
                      JOIN staff s ON u.user_id = s.user_id 
                      WHERE u.id_number = ? AND u.user_type = 'staff'";
        }
        
        $stmt = $db->prepare($query);
        $stmt->execute([$id_number]);
        
        if ($stmt->rowCount() == 1) {
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['id_number'] = $user['id_number'];
            $_SESSION['user_type'] = $user['user_type'];
            $_SESSION['first_name'] = $user['first_name'];
            $_SESSION['last_name'] = $user['last_name'];
            
            if ($user_type === 'patient') {
                $_SESSION['patient_id'] = $user['patient_id'];
                echo json_encode(['success' => true, 'redirect' => 'patient_dashboard.html']);
            } else {
                $_SESSION['staff_id'] = $user['staff_id'];
                $_SESSION['role'] = $user['role'];
                echo json_encode(['success' => true, 'redirect' => 'staff_dashboard.html']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid credentials']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Database error']);
    }
}
?>