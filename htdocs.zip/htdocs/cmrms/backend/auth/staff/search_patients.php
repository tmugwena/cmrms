<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'staff') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

$search_term = $_GET['search'] ?? '';

if (!empty($search_term)) {
    $query = "SELECT p.patient_id, p.first_name, p.last_name, p.phone_number, 
                     p.insurance_provider, u.id_number
              FROM patients p 
              JOIN users u ON p.user_id = u.user_id 
              WHERE p.first_name LIKE ? OR p.last_name LIKE ? OR u.id_number LIKE ?
              ORDER BY p.first_name, p.last_name";
    $stmt = $db->prepare($query);
    $search_pattern = "%$search_term%";
    $stmt->execute([$search_pattern, $search_pattern, $search_pattern]);
    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $patients]);
} else {
    // Get all patients if no search term
    $query = "SELECT p.patient_id, p.first_name, p.last_name, p.phone_number, 
                     p.insurance_provider, u.id_number
              FROM patients p 
              JOIN users u ON p.user_id = u.user_id 
              ORDER BY p.first_name, p.last_name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $patients]);
}
?>