<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'staff') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

$staff_id = $_SESSION['staff_id'];

// Get dashboard statistics
$today = date('Y-m-d');

// Today's appointments
$today_query = "SELECT COUNT(*) as today_appointments 
                FROM appointments 
                WHERE staff_id = ? AND appointment_date = ?";
$today_stmt = $db->prepare($today_query);
$today_stmt->execute([$staff_id, $today]);
$today_appointments = $today_stmt->fetch(PDO::FETCH_ASSOC);

// Total patients
$patients_query = "SELECT COUNT(*) as total_patients FROM patients";
$patients_stmt = $db->prepare($patients_query);
$patients_stmt->execute();
$total_patients = $patients_stmt->fetch(PDO::FETCH_ASSOC);

// Upcoming appointments
$upcoming_query = "SELECT a.*, p.first_name, p.last_name 
                   FROM appointments a 
                   JOIN patients p ON a.patient_id = p.patient_id 
                   WHERE a.staff_id = ? AND a.appointment_date >= ? 
                   ORDER BY a.appointment_date ASC, a.appointment_time ASC 
                   LIMIT 5";
$upcoming_stmt = $db->prepare($upcoming_query);
$upcoming_stmt->execute([$staff_id, $today]);
$upcoming_appointments = $upcoming_stmt->fetchAll(PDO::FETCH_ASSOC);

$dashboard_data = [
    'today_appointments' => $today_appointments['today_appointments'],
    'total_patients' => $total_patients['total_patients'],
    'upcoming_appointments' => $upcoming_appointments
];

echo json_encode(['success' => true, 'data' => $dashboard_data]);
?>