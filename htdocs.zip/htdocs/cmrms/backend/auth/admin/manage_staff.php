<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get all staff
    $query = "SELECT s.*, u.email, u.id_number, u.is_active 
              FROM staff s 
              JOIN users u ON s.user_id = u.user_id 
              ORDER BY s.role, s.first_name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $staff = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $staff]);
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update staff role or status
    $staff_id = $_POST['staff_id'];
    $action = $_POST['action'];
    
    if ($action === 'update_role') {
        $new_role = $_POST['role'];
        $query = "UPDATE staff SET role = ? WHERE staff_id = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$new_role, $staff_id]);
        
        echo json_encode(['success' => true, 'message' => 'Staff role updated successfully']);
        
    } elseif ($action === 'toggle_status') {
        // Get current status
        $status_query = "SELECT u.is_active FROM users u JOIN staff s ON u.user_id = s.user_id WHERE s.staff_id = ?";
        $status_stmt = $db->prepare($status_query);
        $status_stmt->execute([$staff_id]);
        $current_status = $status_stmt->fetch(PDO::FETCH_ASSOC);
        
        $new_status = $current_status['is_active'] ? 0 : 1;
        
        $update_query = "UPDATE users u JOIN staff s ON u.user_id = s.user_id SET u.is_active = ? WHERE s.staff_id = ?";
        $update_stmt = $db->prepare($update_query);
        $update_stmt->execute([$new_status, $staff_id]);
        
        $status_text = $new_status ? 'activated' : 'deactivated';
        echo json_encode(['success' => true, 'message' => "Staff account $status_text"]);
    }
}
?>