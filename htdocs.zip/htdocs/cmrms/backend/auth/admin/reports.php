<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

$report_type = $_GET['type'] ?? 'overview';

switch ($report_type) {
    case 'appointments':
        // Appointment statistics
        $query = "SELECT 
                    COUNT(*) as total_appointments,
                    COUNT(CASE WHEN status = 'Completed' THEN 1 END) as completed,
                    COUNT(CASE WHEN status = 'Scheduled' THEN 1 END) as scheduled,
                    COUNT(CASE WHEN status = 'Cancelled' THEN 1 END) as cancelled,
                    appointment_type
                  FROM appointments 
                  GROUP BY appointment_type";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        break;
        
    case 'patients':
        // Patient statistics
        $query = "SELECT 
                    COUNT(*) as total_patients,
                    insurance_provider,
                    gender
                  FROM patients 
                  GROUP BY insurance_provider, gender";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        break;
        
    case 'overview':
    default:
        // Overview statistics
        $queries = [
            'total_patients' => "SELECT COUNT(*) as count FROM patients",
            'total_staff' => "SELECT COUNT(*) as count FROM staff",
            'total_appointments' => "SELECT COUNT(*) as count FROM appointments",
            'today_appointments' => "SELECT COUNT(*) as count FROM appointments WHERE appointment_date = CURDATE()"
        ];
        
        $data = [];
        foreach ($queries as $key => $sql) {
            $stmt = $db->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $data[$key] = $result['count'];
        }
        break;
}

echo json_encode(['success' => true, 'data' => $data]);
?>