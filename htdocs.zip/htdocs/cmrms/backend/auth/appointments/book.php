<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

if ($_POST) {
    $patient_id = $_SESSION['patient_id'] ?? $_POST['patient_id']; // Staff can book for patients
    $staff_id = $_POST['staff_id'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];
    $appointment_type = $_POST['appointment_type'];
    $reason = $_POST['reason'];
    $created_by = $_SESSION['staff_id'] ?? $staff_id;

    try {
        $query = "INSERT INTO appointments (patient_id, staff_id, appointment_date, 
                  appointment_time, appointment_type, reason, created_by) 
                  VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $db->prepare($query);
        $stmt->execute([$patient_id, $staff_id, $appointment_date, $appointment_time, 
                       $appointment_type, $reason, $created_by]);
        
        echo json_encode(['success' => true, 'message' => 'Appointment booked successfully']);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Booking failed: ' . $e->getMessage()]);
    }
}
?>