<?php
header('Content-Type: application/json');
require_once '../../config/database.php';

session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'patient') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

$patient_id = $_SESSION['patient_id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get patient profile
    $query = "SELECT p.*, u.email, u.id_number 
              FROM patients p 
              JOIN users u ON p.user_id = u.user_id 
              WHERE p.patient_id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$patient_id]);
    $patient = $stmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $patient]);
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update patient profile
    $phone_number = $_POST['phone_number'];
    $address = $_POST['address'];
    $insurance_provider = $_POST['insurance_provider'];
    
    $query = "UPDATE patients SET phone_number = ?, address = ?, insurance_provider = ? 
              WHERE patient_id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$phone_number, $address, $insurance_provider, $patient_id]);
    
    echo json_encode(['success' => true, 'message' => 'Profile updated successfully']);
}
?>